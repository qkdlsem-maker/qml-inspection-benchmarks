"""Audit the angles used in the four-qubit ProBayes models by production date."""
import argparse
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def audit(source):
    with source.open("rb") as stream:
        if hashlib.file_digest(stream, "sha256").hexdigest() != "515ae0548520bdcd04609b5def646246122d116ab72ae07e058e206c8319142e":
            raise ValueError("Expected the original pinned ProBayes CSV")
    sensors = ["QUA_CycleTime", "QUA_InjectionTime", "QUA_PlastificationTime", "QUA_CushionVolume",
               "QUA_InjectionPressureMax", "QUA_TransferPressure", "QUA_TransferStroke", "QUA_OilTemperature"]
    frame = pd.read_csv(source, usecols=[*sensors, "MET_TimeCycleStart", "MET_MachineCycleID"])
    frame = frame.sort_values(["MET_TimeCycleStart", "MET_MachineCycleID"], kind="stable")
    days = pd.to_datetime(frame.MET_TimeCycleStart).dt.strftime("%Y-%m-%d")
    train = days.eq("2021-12-07")
    transform = make_pipeline(SimpleImputer(strategy="median"), VarianceThreshold(), StandardScaler(),
                              PCA(n_components=4, svd_solver="full"))
    pcs = transform.fit_transform(frame.loc[train, sensors])
    scale = 0.5 / np.sqrt(np.mean(pcs**2))
    rows = []
    for date in sorted(days.unique()):
        a = scale * (pcs if date == "2021-12-07" else transform.transform(frame.loc[days.eq(date), sensors]))
        maximum = np.abs(a[:, :-1] * a[:, 1:]).max(axis=1)
        rows.append(dict(date=date, units=len(a), median_max_abs_RZZ_rad=np.median(maximum),
                         largest_abs_RZZ_rad=maximum.max(), units_with_max_gt_2pi=int((maximum > 2*np.pi).sum())))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("probayes_csv", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    audit(args.probayes_csv).to_csv(args.output, index=False)
