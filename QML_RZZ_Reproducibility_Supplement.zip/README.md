# Reproducing the RZZ inspection benchmark revision

These files reproduce the additional analyses of daily defect inspection by Hyerim Choi and Tae-Kook Kim. The base notebooks, source locations, data identifiers, earlier aggregate results, and pinned Python dependencies are in [the original benchmark at e7068d1ca1d6](https://github.com/qkdlsem-maker/qml-inspection-benchmarks/tree/e7068d1ca1d6). Both die-casting test periods had already been studied when the new protocols were written. The training and evaluation stages are recorded separately to make their chronology inspectable.

## Compare the two circuits

The four-qubit circuits receive the same four components, circuit depth, training records and daily capacity. Each circuit layer in the coupled version adds three nearest-neighbor RZZ rotations. The shared-setting analysis selects one phase scale and one SVM regularization parameter for both circuits. The per-family analysis selects a configuration separately for each kernel and gives each the same number of candidates. The Gaussian kernel multiplier and circuit phase scale have different definitions.

| Analysis | Result file | Reproduction |
|---|---|---|
| Fixed-C scale sensitivity on the original cohorts and both casting windows | `scale/original/fixed_scale_summary.csv`, `scale/casting/casting_scale_sweep.csv` | `scale/QML_RZZ_Scale_Sensitivity.ipynb` includes all 56 counts and the executable comparison. |
| Absolute rotation angles in the original molding cohort | `phase/probayes_angles.csv` | `python phase/probayes_angles.py data/probayes.csv phase/probayes_angles.csv` |
| Primary grid for the retrospective casting extension | `tuning/results/tuning_test_summary.csv` | Follow `tuning/README.md` to reproduce the 12 candidates per family and the three expanding temporal folds. |
| Lower-edge sensitivity | `tuning/boundary/results/tuning_test_summary.csv` | Follow `tuning/boundary/README.md` after completing the initial grid. Six more candidates per family test the original lower edge. |
| Conditional uncertainty for the common setting in the 12-candidate grid | `paired/paired_intervals.csv` | Extract per-day paired counts and resample circular blocks of five consecutive recorded dates. |
| Full-sensor supervised comparators at two training sizes | `practical/practical_results.csv` | `practical/practical_protocol.md` gives the configuration and command for Extra Trees and histogram gradient boosting. |
| Agreement of both ProBayes conversions with official Parquet | `provenance/provenance_audit.json` | Install `pyarrow==23.0.1` alongside the base dependencies, then run `python provenance/verify_probayes_sources.py official data --output provenance/provenance_audit.json`. |
| Casting input-scale figure | `scale/casting/casting_scale_sweep.csv` | Run `python scale/casting/scale_figure.py` to regenerate the figure at 600 dpi. |

For the original ProBayes release download `dataset_V2.parquet` from [EUDAT v2](https://b2share.eudat.eu/records/k0v7s-jf859). For the November release download `dataset.parquet` from [EUDAT v1](https://b2share.eudat.eu/records/v64sz-f0f41). Place both under `official/` for the check above. The key is the unique machine cycle identifier, and the endpoint checked is the binary LBL_NOK label.

The paired interval commands run from the top of this supplement:

```sh
python paired/from_tuning.py tuning/results/tuning_test_by_date.csv paired/paired_daily.csv
python paired/paired_intervals.py paired/paired_daily.csv paired/paired_intervals.csv
```

The intervals condition on the fitted models and realized daily quotas. A detection difference of zero throughout one observed window can produce a degenerate empirical interval. The results describe the recorded dates at one plant. They do not establish equivalence in future production.

For casting, `all` uses the daily capacity among all eligible shots. The `unmarked` rows recalculate the daily capacity among shots with a blank trial code and score this subset with the same fitted models. The calibration target in the chronological model selection is the total number of labeled defects found in all shots in the three validation windows. No raw production records are included in this supplement. Obtain them from the exact source revisions listed in the base repository. Aggregate outputs retain counts, and do not contain sensor-level shot records.
