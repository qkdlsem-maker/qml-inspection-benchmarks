# Source verification and data use

Checked 25 November 2026. The accompanying files contain aggregate source comparisons and executable checks. The published source records and the copies used for analysis are identified below.

## ProBayes

For the two ProBayes experiments, the publisher's Parquet download was checked against the MD5 digest posted on its record. The SHA-256 digest of each analysis CSV was checked against the benchmark's pinned copy. Matching on the unique machine-cycle identifier recovered 564 parts in the original release and 303 in the November release. The eight model sensors matched exactly across all 6,936 field values. The outcome, start time, production setting, material and chronological order agreed for all parts. The program compares fields used in this study. The aggregate field counts and digests are recorded in `provenance_audit.json`.

- [ProBayes original, version 2](https://b2share.eudat.eu/records/k0v7s-jf859)
- [ProBayes D-optimal campaign, version 1](https://b2share.eudat.eu/records/v64sz-f0f41)

## Korean competition casting data

The 24 October 2024 task announcement from the fourth K-AI Manufacturing Data Analysis Competition identifies the casting optimization dataset and explicitly gives the competition filename `경진대회용 주조 공정최적화 데이터셋.csv`. This is the basename of the longer pinned file used in the study. The competition's short and long versions used for analysis are identified by commit, path and digest in the original benchmark. The public assignment page currently lists a JPG information sheet and two HWP documents. Its download link points to the general notice board. Neither the public task text and attachment nor the public call for entries and attachment provided a checksum for the competition CSV or specified publication and redistribution terms for nonparticipants. The call refers to an online participant pledge. Its provisions were unavailable in the inspected documents.

- [Official KAMP assignment and attachments](https://www.kamp-ai.kr/contestNoticeDetail?CPT_NOTICE_SEQ=18)
- [Parallel KAMP portal announcement](https://www.kamp-ai.kr/noticeDetail?NOTICE_SEQ=76)
- [Official call for entries and attachment](https://www.kamp-ai.kr/contestNoticeDetail?CPT_NOTICE_SEQ=16)
- [Short-file repository](https://github.com/yeonduhaeyo/diecasting-project/tree/301062144132) and [long-file repository](https://github.com/greatsangho/2024-Kamp-Competition/tree/ad2b1147ea73)

KAMP also lists a general casting-process optimization dataset under catalog entry 53. The catalog lists 73,612 rows and 23 analysis variables, and its preview displays a 2021 production date. The competition files analyzed here contain 2019 dates. Catalog entry 53 and the injection-molding catalog entry 4 list modification of content as permitted and research/paper writing among the intended purposes. Their attribution instructions identify the required citation components and request that authors send the cited material/document to the KAMP contact. These catalog statements do not independently identify either competition file byte for byte or establish permission to redistribute a competition CSV.

- [KAMP casting catalog, entry 53](https://www.kamp-ai.kr/aidataDetail?DATASET_SEQ=53)
- [KAMP injection molding catalog, entry 4](https://www.kamp-ai.kr/aidataDetail?DATASET_SEQ=4)

For the competition files, the authors can ask the competition operator to confirm the official version and applicable conditions for publishing aggregate findings from the 2019 records. The operator listed in the task announcement is the KAIST Manufacturing AI Big Data Center, `kamp@kaist.ac.kr`. This review did not establish an independent right to publish raw copies.
