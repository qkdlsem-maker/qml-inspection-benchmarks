"""Check the analysis fields of the two pinned ProBayes CSV conversions against EUDAT Parquet.

Use python verify_probayes_sources.py OFFICIAL_DIR CSV_DIR --output provenance_audit.json
Official filenames and checksums appear in RELEASES. This script emits no individual records.
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


RELEASES = (
    ("original", "https://b2share.eudat.eu/records/k0v7s-jf859", "dataset_V2.parquet",
     "f04efe419e63db5fb4a392e1569ea417", "probayes.csv",
     "515ae0548520bdcd04609b5def646246122d116ab72ae07e058e206c8319142e"),
    ("november", "https://b2share.eudat.eu/records/v64sz-f0f41", "dataset.parquet",
     "913cb30061ba35b78cc7715799674783", "probayes_nov2022_mirror.csv",
     "3bfccc61e610d4536168e2a91bb2d9ba8ad6a9bfac5c1b6a80d6a7efaa15c886"),
)
KEY = "MET_MachineCycleID"
TIME = "MET_TimeCycleStart"
SETTING = "MET_ExperimentNumber"
MATERIAL = "MET_MaterialName"
LABEL = "LBL_NOK"
SENSORS = [
    "QUA_CycleTime", "QUA_InjectionTime", "QUA_PlastificationTime", "QUA_CushionVolume",
    "QUA_InjectionPressureMax", "QUA_TransferPressure", "QUA_TransferStroke", "QUA_OilTemperature",
]


def checked_hash(path, algorithm, expected):
    with path.open("rb") as source:
        actual = hashlib.file_digest(source, algorithm).hexdigest()
    if actual != expected:
        raise ValueError(f"{path.name}: {algorithm} {actual} differs from expected {expected}")
    return actual


def audit(release, official_dir, csv_dir):
    tag, url, parquet, expected_md5, csv_name, expected_sha = release
    source = official_dir / parquet
    mirror = csv_dir / csv_name
    checked_hash(source, "md5", expected_md5)
    checked_hash(mirror, "sha256", expected_sha)
    cols = [KEY, TIME, SETTING, MATERIAL, LABEL, *SENSORS]
    frames = [pd.read_parquet(source, columns=cols), pd.read_csv(mirror, usecols=cols)]
    for frame in frames:
        frame[KEY] = pd.to_numeric(frame[KEY], errors="raise")
        frame[TIME] = pd.to_datetime(frame[TIME], errors="raise")
        if frame[KEY].isna().any() or not frame[KEY].is_unique or frame[TIME].isna().any():
            raise ValueError(f"{tag}: missing or duplicate analysis key, or missing timestamp")
    original, conversion = frames
    if set(original[KEY]) != set(conversion[KEY]):
        raise ValueError(f"{tag}: different sets of machine cycle identifiers")
    source_order = original.sort_values([TIME, KEY])[KEY].tolist()
    csv_order = conversion.sort_values([TIME, KEY])[KEY].tolist()
    indexes = [frame.set_index(KEY).sort_index() for frame in frames]
    left, right = indexes
    sensor_differences = {}
    for name in SENSORS:
        a = pd.to_numeric(left[name], errors="raise").to_numpy(dtype=float)
        b = pd.to_numeric(right[name], errors="raise").to_numpy(dtype=float)
        if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
            raise ValueError(f"{tag}: non-finite {name}")
        difference = np.abs(a - b)
        sensor_differences[name] = {
            "comparisons": int(len(a)), "unequal_numeric_values": int(np.count_nonzero(difference)),
            "max_absolute_difference": float(np.max(difference)),
        }
    fields = {name: int(np.count_nonzero(left[name].to_numpy() != right[name].to_numpy()))
              for name in (TIME, SETTING, MATERIAL, LABEL)}
    return {
        "release": tag, "official_record": url, "official_filename": parquet, "official_md5": expected_md5,
        "conversion_filename": csv_name, "conversion_sha256": expected_sha,
        "matched_unique_ids": int(len(left)), "same_physical_row_order": original[KEY].tolist() == conversion[KEY].tolist(),
        "identical_analysis_order_after_time_sort": source_order == csv_order,
        "positive_labels_official_csv": [int(frame[LABEL].sum()) for frame in frames],
        "unequal_metadata_values": fields, "sensors": sensor_differences,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("official_dir", type=Path)
    parser.add_argument("csv_dir", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = [audit(release, args.official_dir, args.csv_dir) for release in RELEASES]
    report = json.dumps(result, indent=2, allow_nan=False) + "\n"
    if args.output:
        args.output.write_text(report, encoding="utf-8")
    else:
        print(report, end="")
    if any(not entry["identical_analysis_order_after_time_sort"]
           or any(entry["unequal_metadata_values"].values())
           or any(values["unequal_numeric_values"] for values in entry["sensors"].values())
           for entry in result):
        raise SystemExit("At least one comparison differs; inspect the aggregate report.")
