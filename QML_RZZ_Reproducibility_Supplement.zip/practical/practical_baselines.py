"""Retrospective training-history comparison from practical_protocol.md."""
import argparse
import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits


def models():
    return {
        "Extra Trees": ExtraTreesClassifier(
            n_estimators=500, criterion="gini", min_samples_leaf=5, max_features="sqrt",
            max_depth=None, bootstrap=False, class_weight="balanced", random_state=20261123,
            n_jobs=1,
        ),
        "Histogram gradient boosting": HistGradientBoostingClassifier(
            loss="log_loss", learning_rate=0.1, max_iter=100, max_leaf_nodes=31,
            min_samples_leaf=20, l2_regularization=0, max_bins=255, early_stopping=False,
            class_weight="balanced", random_state=20261123,
        ),
    }


def daily_totals(frame, labels, quotas):
    groups = list(frame.groupby(frame.time.dt.normalize(), sort=True))
    allowance = quotas(np.array([len(rows) for _, rows in groups]), "Largest remainder")
    result = []
    for (date, rows), available in zip(groups, allowance):
        selected = rows.sort_values("score", ascending=False, kind="stable").iloc[:available]
        result.append(dict(**labels, date=date.date().isoformat(), shots=len(rows),
                           positives=int(rows.target.sum()), slots=int(available),
                           hits=int(selected.target.sum()),
                           hits_D=int(selected.loc[selected.flag_D, "target"].sum())))
    return result


def main(args):
    sys.path.insert(0, str(args.repo.resolve() / "external"))
    import casting_trees as ref
    from external_diecasting import quotas
    prefix = ref.load_data(args.prefix, ref.PREFIX_URL, ref.PREFIX_SHA, "utf-8-sig")
    full = ref.load_data(args.full, ref.FULL_URL, ref.FULL_SHA, "cp949")
    for frame in (prefix, full):
        assert frame.tryshot_signal.fillna("").str.strip().isin(["", "D"]).all()
    sample, windows = ref.select_rows(prefix, full)
    initial_date = windows["Primary"].time.min().normalize()
    entire = prefix.loc[prefix.target.isin([0, 1]) & (prefix.time < initial_date)].sort_values("time", kind="stable")
    assert len(entire) == 46696 and entire.time.dt.normalize().nunique() == 46
    assert sample.index.isin(entire.index).all() and len(sample) == 2048
    totals, daily, experiment = [], [], {}
    for training in (sample, entire):
        pipe = make_pipeline(SimpleImputer(strategy="median"), VarianceThreshold(), StandardScaler())
        x_train = pipe.fit_transform(ref.numeric(training))
        retained = pipe.get_feature_names_out(ref.SENSORS).tolist()
        experiment[str(len(training))] = {
            "positive": int(training.target.sum()), "retained": retained,
            "index_sha256": hashlib.sha256(np.asarray(training.index, dtype="<i8").tobytes()).hexdigest(),
        }
        x_windows = {name: pipe.transform(ref.numeric(frame)) for name, frame in windows.items()}
        y = training.target.to_numpy(dtype=np.int8)
        for model_name, model in models().items():
            model.fit(x_train, y)
            np.testing.assert_array_equal(model.classes_, [0, 1])
            for window, frame in windows.items():
                scored = frame.assign(score=model.predict_proba(x_windows[window])[:, 1])
                assert np.isfinite(scored.score).all()
                for population, eligible in (("all", scored), ("unmarked", scored.loc[~scored.flag_D])):
                    labels = dict(training_rows=len(training), model=model_name, window=window,
                                  population=population)
                    daily_rows = daily_totals(eligible, labels, quotas)
                    daily.extend(daily_rows)
                    original = ref.summarize(window, population, eligible, "score")
                    for key, aggregate in (("shots", "eligible"), ("positives", "positive"),
                                           ("hits", "hits"), ("slots", "slots"), ("hits_D", "hits_D")):
                        assert sum(row[key] for row in daily_rows) == original[aggregate]
                    totals.append(dict(**labels, dates=original["dates"], shots=original["eligible"],
                                       positives=original["positive"], slots=original["slots"],
                                       hits=original["hits"], hits_D=original["hits_D"],
                                       recall=original["recall"], pooled_ap=original["pooled_ap"]))
    table = pd.DataFrame(totals)
    subset = table[(table.training_rows == 2048) & (table.model == "Extra Trees")]
    assert subset.set_index(["window", "population"]).hits.to_dict() == {
        ("Primary", "all"):935, ("Continuation", "all"):596,
        ("Primary", "unmarked"):185, ("Continuation", "unmarked"):43,
    }
    args.out.mkdir(exist_ok=True, parents=True)
    table.to_csv(args.out / "practical_results.csv", index=False, lineterminator="\n")
    pd.DataFrame(daily).to_csv(args.out / "practical_by_date.csv", index=False, lineterminator="\n")
    info = {"protocol_sha256": hashlib.sha256(Path(__file__).with_name("practical_protocol.md").read_bytes()).hexdigest(),
            "source_sha256": [ref.PREFIX_SHA, ref.FULL_SHA],
            "runtime": {"python": platform.python_version(), "numpy": np.__version__,
                        "pandas": pd.__version__, "sklearn": sklearn.__version__},
            "training": experiment}
    (args.out / "practical_metadata.json").write_text(json.dumps(info, indent=2)+"\n", encoding="utf-8")
    print(table.pivot(index=["training_rows", "model"], columns=["window", "population"], values="hits").to_string())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ["repo", "prefix", "full", "out"]:
        parser.add_argument("--" + name, type=Path, required=True)
    with threadpool_limits(limits=1):
        main(parser.parse_args())
