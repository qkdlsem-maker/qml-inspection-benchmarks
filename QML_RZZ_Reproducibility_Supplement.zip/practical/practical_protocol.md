# Training-history sensitivity of full-sensor casting baselines

This retrospective extension is specified before fitting its models. The earlier paper and descriptive results for both test windows are already known. Both model families and all four training-size/model combinations are retained irrespective of their validation-window outcomes. No test-driven selection is performed.

Use the verified casting sources and the chronological cohorts from the benchmark at commit `e7068d1ca1d6`. Fit on the prefix source's first 46 eligible registration dates (January 2 through February 20, 2019). Compare the original outcome-independent hash-selected 2,048 shots with all 46,696 eligible shots. For each fit use only the 17 published sensor columns. Fit median imputation, constant-feature removal and standardization on the corresponding training sample. Record the subsequently retained features. Exclude trial codes, outcomes, timestamps and identifiers from predictors.

1. Replicate the paper's full-sensor Extra Trees comparator with 500 estimators, Gini criterion, balanced class weighting, minimum leaf size 5, square-root feature fraction, unrestricted depth, no bootstrap, and seed 20261123.
2. Fit histogram gradient boosting with log loss, 100 iterations, learning rate 0.1, 31 maximum leaves, minimum leaf size 20, L2 penalty 0, 255 bins, no early stopping, balanced class weighting and seed 20261123. No search is performed.

Score the initial 20 dates from the shorter source and the subsequent 19 dates from the longer source with each fixed fitted model. Use descending positive-class probability, resolving ties by registration time, then source-row order. Compute a 10% largest-remainder daily allocation separately per window and population, on either all eligible shots or only those whose trial marker is blank. Keep the same scores in both populations. Report every pair of absolute counts, with eligible shots, slots, positives and daily counts. A four-cell regression check must reproduce the published 2,048-shot Extra Trees counts (935/596 for all, 185/43 for unmarked). Known codes D and blank are checked against both raw files.

Run from the directory containing the public benchmark's external folder with the repository path, two verified CSV files, and output directory supplied explicitly.

```sh
python practical_baselines.py --repo /path/to/qml-inspection-benchmarks --prefix /path/to/diecasting_train.csv --full /path/to/competition_full.csv --out /path/to/results
```
