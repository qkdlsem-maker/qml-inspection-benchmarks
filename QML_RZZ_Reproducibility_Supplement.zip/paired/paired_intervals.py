"""Calculate conditional, within-window uncertainty for a matched RZZ comparison.

Input CSV columns: window, eligibility, day, slots, coupled_hits, uncoupled_hits.
Only the common train-selected phase and C belong in this input.
Usage: python paired_intervals.py paired_daily.csv paired_intervals.csv
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def summarize(group):
    g = group.sort_values("day")
    if g["day"].duplicated().any() or len(g) < 5:
        raise ValueError("Expected unique dates and at least five dates per window")
    columns = ["slots", "coupled_hits", "uncoupled_hits"]
    if g[columns].isna().any().any() or (g[columns] < 0).any().any():
        raise ValueError("Counts must be complete and nonnegative")
    if (g.coupled_hits > g.slots).any() or (g.uncoupled_hits > g.slots).any():
        raise ValueError("Detections cannot exceed available inspections")
    slots = g.slots.to_numpy()
    diff = (g.coupled_hits - g.uncoupled_hits).to_numpy()
    rng = np.random.default_rng(20261125)
    n = len(g)
    starts = rng.integers(n, size=(10000, (n + 4) // 5))
    idx = ((starts[:, :, None] + np.arange(5)) % n).reshape(10000, -1)[:, :n]
    denom = slots[idx].sum(axis=1)
    if denom.min() <= 0:
        raise ValueError("Zero denominator in bootstrap")
    distribution = 100 * diff[idx].sum(axis=1) / denom
    low, high = np.quantile(distribution, [0.025, 0.975])
    return dict(days=n, slots=int(slots.sum()), coupled_hits=int(g.coupled_hits.sum()),
                uncoupled_hits=int(g.uncoupled_hits.sum()), delta=int(diff.sum()),
                delta_per_100_slots=100 * diff.sum() / slots.sum(), low=low, high=high,
                win_days=int((diff > 0).sum()), tie_days=int((diff == 0).sum()),
                loss_days=int((diff < 0).sum()))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("daily", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    rows = []
    for (window, eligibility), group in pd.read_csv(args.daily).groupby(["window", "eligibility"], sort=True):
        rows.append(dict(window=window, eligibility=eligibility, **summarize(group)))
    pd.DataFrame(rows).to_csv(args.output, index=False)
