"""Extract a verified paired per-date input from the tuning analysis."""
import argparse
from pathlib import Path

import pandas as pd


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tuning_by_date", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    d = pd.read_csv(args.tuning_by_date)
    d = d.loc[d.selection.eq("shared_q_setting")]
    if len(d[["scale", "C"]].drop_duplicates()) != 1:
        raise ValueError("Expected one shared parameter pair across windows and methods")
    key = ["window", "eligible", "date", "units", "slots", "defects"]
    table = d.pivot(index=key, columns="method", values="hits").reset_index()
    if len(table) != 78 or table.isna().any().any():
        raise ValueError("Expected a complete daily pair for each window and eligibility rule")
    table.rename(columns={"eligible":"eligibility", "date":"day", "Q4 + RZZ":"coupled_hits",
                          "Q4 no RZZ":"uncoupled_hits"}).to_csv(args.output, index=False)
