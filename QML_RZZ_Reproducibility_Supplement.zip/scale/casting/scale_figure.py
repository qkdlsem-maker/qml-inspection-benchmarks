from pathlib import Path
import csv
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.ticker import MaxNLocator

here = Path(__file__).resolve().parent
source = here / "casting_scale_sweep.csv"
with source.open(encoding="utf-8") as stream:
    rows = list(csv.DictReader(stream))
series = {}
for row in rows:
    if row["eligible"] == "all":
        series.setdefault((row["window"], row["coupled"]), {})[float(row["phase"])] = int(row["hits"])

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8, "ytick.labelsize": 7.5,
                     "xtick.labelsize": 7.5, "axes.spines.top": False, "axes.spines.right": False})
scales = [0.25, 0.5, 1, 2]
fig, axes = plt.subplots(2, 1, figsize=(3.30, 2.95), sharex=True)
for ax, win, title, ticks in zip(axes, ["first", "second"], ["(a) First 20 dates", "(b) Next 19 dates"], [[0, 450, 900],[0, 300, 600]]):
    for key, name, color, marker, style in [("True","RZZ on","#005D73","o","-"),("False","RZZ off","#8A4312","s","--")]:
        y = [series[win,key][scale] for scale in scales]
        ax.plot(range(4), y, color=color, lw=1.45, ls=style, marker=marker, ms=4.6,
                markerfacecolor=color if key=="True" else "white", label=name, zorder=3 if key=="False" else 4)
    ax.set(ylim=(-10, ticks[-1]*1.12), yticks=ticks, xlim=(-0.12,3.12))
    ax.grid(axis="y",color="#dddddd",lw=.5)
    ax.set_title(title, loc="left", fontsize=8.2, fontweight="bold",pad=2)
    ax.tick_params(length=2.5)
axes[0].legend(loc="center right", bbox_to_anchor=(1.02,1.20),ncols=2, frameon=False, fontsize=7.3,handlelength=1.65,columnspacing=.9)
axes[1].set(xticks=range(4),xticklabels=["0.25","0.5","1","2"],xlabel="Input phase scale")
fig.text(.025,.53,"Defects retrieved",rotation=90,ha="center",va="center",fontsize=8)
fig.subplots_adjust(left=.17,right=.98,top=.87,bottom=.17,hspace=.48)
fig.savefig(here/"rzz_casting_scale.png",dpi=600,facecolor="white")
