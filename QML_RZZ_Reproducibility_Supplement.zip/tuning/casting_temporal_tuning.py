"""Train-only temporal tuning followed by retrospective evaluation of frozen choices."""
import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.decomposition import PCA
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


@dataclass
class Shots:
    x: pd.DataFrame
    y: pd.Series
    day: pd.Series
    blank: pd.Series
    order: pd.Index


def load(raw, lib):
    enc, sensors, time_col, label_col, _ = lib.schema(raw)
    frame = pd.read_csv(BytesIO(raw), encoding=enc, usecols=[*sensors,time_col,label_col,"tryshot_signal"], dtype=str)
    times = pd.to_datetime(frame[time_col], format="mixed", errors="coerce")
    y = pd.to_numeric(frame[label_col], errors="coerce")
    valid = times.notna() & y.isin([0, 1])
    order = times[valid].sort_values(kind="stable").index
    flags = frame["tryshot_signal"].fillna("").str.strip()
    if not flags.isin(["", "D"]).all():
        raise ValueError("Unrecognized trial-shot status")
    x = frame[sensors].apply(pd.to_numeric, errors="coerce").replace([np.inf,-np.inf],np.nan)
    return Shots(x, y, times.dt.normalize(), flags.eq(""), order)


def select_rows(data, dates):
    return data.order[data.day.loc[data.order].isin(dates)]


def sample_rows(ids):
    chosen = sorted(ids, key=lambda i: hashlib.sha256(str(i).encode("ascii")).digest())[:2048]
    return ids[ids.isin(set(chosen))]


def prepare_features(data, train, windows):
    transform = make_pipeline(SimpleImputer(strategy="median"), VarianceThreshold(), StandardScaler())
    pca = PCA(n_components=4, svd_solver="full")
    tx = pca.fit_transform(transform.fit_transform(data.x.loc[train]))
    vx = np.concatenate([pca.transform(transform.transform(other.x.loc[ix])) for other, ix in windows])
    y = data.y.loc[train].to_numpy(dtype=np.int8)
    return tx, vx, y


def fit_scores(lib, method, scale, costs, tx, vx, y):
    if method == "PCA4 RBF":
        gamma = scale / (tx.shape[1] * tx.var())
        return {c: SVC(C=c, kernel="rbf", gamma=gamma, class_weight="balanced").fit(tx,y).decision_function(vx)
                for c in costs}
    normalized = scale / np.sqrt(np.mean(tx**2))
    states = lib.four_qubit_states(tx * normalized, method == "Q4 + RZZ")
    test = lib.four_qubit_states(vx * normalized, method == "Q4 + RZZ")
    train_gram = lib.gram(states, states)
    models = {c: SVC(C=c, kernel="precomputed", class_weight="balanced").fit(train_gram,y) for c in costs}
    scores = {c: np.empty(len(vx)) for c in costs}
    for i in range(0, len(test), 192):
        block = slice(i, min(i+192, len(test)))
        cross = lib.gram(test[block], states)
        for c, model in models.items():
            scores[c][block] = model.decision_function(cross)
    return scores


def summarize(lib, shots, ids, values, eligible):
    if not np.isfinite(values).all():
        raise ValueError("Non-finite decision scores")
    df = pd.DataFrame({"day":shots.day.loc[ids].to_numpy(), "label":shots.y.loc[ids].to_numpy(dtype=np.int8),
                       "score":values})
    if eligible == "unmarked":
        df = df[shots.blank.loc[ids].to_numpy()]
    groups = list(df.groupby("day",sort=True))
    slots = lib.quotas(np.array([len(g) for day,g in groups]), "Largest remainder")
    records = []
    for (day,g), k in zip(groups,slots):
        y = g.label.to_numpy()
        order = np.argsort(-g.score.to_numpy(), kind="stable")
        records.append({"date":day.date().isoformat(),"units":len(y),"slots":int(k),"defects":int(y.sum()),
                        "hits":int(y[order[:k]].sum())})
    return records


def choose(totals):
    return totals.sort_values(["hits", "C", "scale"], ascending=[False, True, True]).iloc[0]


def write_json(p, obj):
    p.write_text(json.dumps(obj, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def validate(args, spec, lib):
    shots = load(lib.bytes_for_analysis(args.short), lib)
    train = shots.order[shots.day.loc[shots.order] <= pd.Timestamp("2019-02-20")]
    days = shots.day.loc[train].unique()
    assert (len(days),len(train)) == (46,46696)
    daily, fold_meta = [], []
    for n in spec["fold_training_days"]:
        subset = select_rows(shots,days[:n])
        fit = sample_rows(subset)
        val = select_rows(shots, days[n:n+spec["subsequent_validation_days"]])
        assert shots.day.loc[fit].max() < shots.day.loc[val].min()
        tx, vx, y = prepare_features(shots,fit,[(shots,val)])
        assert len(np.unique(y)) == 2
        fold_meta.append({"fit_dates":n,"fit_last":str(days[n-1].date()),"fit_pool":len(subset),
                          "fit_sample":len(fit),"fit_positives":int(y.sum()),
                          "fit_source_ids_sha256":sha(np.array(fit,dtype="<i8").tobytes()),
                          "validation_first":str(days[n].date()),"validation_last":str(days[n+9].date()),
                          "validation_units":len(val),"validation_positives":int(shots.y.loc[val].sum())})
        for method in spec["methods"]:
            for scale in spec["scale_candidates"]:
                scores = fit_scores(lib,method,scale,spec["C_candidates"],tx,vx,y)
                for c,score in scores.items():
                    for row in summarize(lib,shots,val,score,"all"):
                        daily.append({"fit_dates":n,"method":method,"scale":scale,"C":c,**row})
        print("Validated fold through",days[n+9].date(),flush=True)
    detail = pd.DataFrame(daily)
    detail.to_csv(args.out/"tuning_validation_by_date.csv",index=False)
    totals = detail.groupby(["method","scale","C"],as_index=False)[["units","slots","defects","hits"]].sum()
    totals.to_csv(args.out/"tuning_validation_grid.csv",index=False)
    assert totals.groupby("method").size().eq(12).all() and totals.slots.nunique()==1
    write_json(args.out/"tuning_folds.json",fold_meta)
    selections=[]
    for method in spec["methods"]:
        best=choose(totals.loc[totals.method.eq(method)])
        selections.append({"selection":"individually_tuned","method":method,"scale":float(best.scale),"C":float(best.C),
                           "validation_hits":int(best.hits)})
    pair=totals[totals.method.str.startswith("Q4")].groupby(["scale","C"],as_index=False).hits.sum()
    best=choose(pair)
    for method in spec["methods"][:2]:
        count=totals.loc[totals.method.eq(method)&totals.scale.eq(best.scale)&totals.C.eq(best.C),"hits"].item()
        selections.append({"selection":"shared_q_setting","method":method,"scale":float(best.scale),"C":float(best.C),
                           "validation_hits":int(count)})
    for method,scale in zip(spec["methods"],(.5,.5,1.)):
        count=totals.loc[totals.method.eq(method)&totals.scale.eq(scale)&totals.C.eq(1),"hits"].item()
        selections.append({"selection":"original_setting","method":method,"scale":scale,"C":1.,"validation_hits":int(count)})
    pd.DataFrame(selections).to_csv(args.out/"tuning_choices.csv",index=False)
    write_json(args.out/"tuning_selection_manifest.json",{
        "protocol_sha256":sha(args.protocol.read_bytes()),"choices_sha256":sha((args.out/"tuning_choices.csv").read_bytes()),
        "input_sha256_short":sha(args.short.read_bytes()),"python":platform.python_version(),"numpy":np.__version__,
        "pandas":pd.__version__,"sklearn":sklearn.__version__,"threads":1})
    print(pd.DataFrame(selections).to_string(index=False),flush=True)


def evaluate(args,spec,lib,full_source):
    manifest=json.loads((args.out/"tuning_selection_manifest.json").read_text(encoding="utf-8"))
    if manifest["protocol_sha256"] != sha(args.protocol.read_bytes()) or manifest["choices_sha256"] != sha((args.out/"tuning_choices.csv").read_bytes()):
        raise ValueError("Frozen protocol or choices changed")
    choices=pd.read_csv(args.out/"tuning_choices.csv")
    short=load(lib.bytes_for_analysis(args.short),lib)
    long=load(full_source(args.long),lib)
    assert short.x.columns.tolist()==long.x.columns.tolist()
    train=short.order[short.day.loc[short.order]<=pd.Timestamp("2019-02-20")]
    fit=sample_rows(train)
    first=short.order[short.day.loc[short.order]>pd.Timestamp("2019-02-20")]
    second=long.order[long.day.loc[long.order]>pd.Timestamp("2019-03-12")]
    assert (len(fit),int(short.y.loc[fit].sum()),len(first),len(second))==(2048,124,26916,17306)
    tx,vx,y=prepare_features(short,fit,[(short,first),(long,second)])
    daily=[]
    for (method,scale), configs in choices.groupby(["method","scale"]):
        scores=fit_scores(lib,method,scale,sorted(configs.C.unique()),tx,vx,y)
        for row in configs.itertuples(index=False):
            score=scores[row.C]
            for window,shots,ids,s in (("first",short,first,score[:len(first)]),("second",long,second,score[len(first):])):
                for eligible in ("all","unmarked"):
                    for rec in summarize(lib,shots,ids,s,eligible):
                        daily.append({"selection":row.selection,"method":method,"scale":scale,"C":row.C,
                                      "window":window,"eligible":eligible,**rec})
    details=pd.DataFrame(daily)
    details.to_csv(args.out/"tuning_test_by_date.csv",index=False)
    totals=details.groupby(["selection","method","scale","C","window","eligible"],as_index=False)[["units","slots","defects","hits"]].sum()
    original=totals[totals.selection.eq("original_setting")].pivot(index="method",columns=["window","eligible"],values="hits")
    expected={"Q4 + RZZ":(883,179,516,26),"Q4 no RZZ":(875,184,523,28),"PCA4 RBF":(689,150,432,22)}
    for method, counts in expected.items():
        assert tuple(original.loc[method,[(w,e) for w in ("first","second") for e in ("all","unmarked")]])==counts
    totals.to_csv(args.out/"tuning_test_summary.csv",index=False)
    print(totals.pivot(index=["selection","method","scale","C"],columns=["window","eligible"],values="hits").to_string(),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage",choices=["validate","evaluate","both"])
    for flag in ["repo","short","long","out"]:
        parser.add_argument("--"+flag,required=True,type=Path)
    parser.add_argument("--protocol",type=Path,default=Path(__file__).with_name("tuning_protocol.json"))
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    spec=json.loads(args.protocol.read_text(encoding="utf-8"))
    sys.path.insert(0,str((args.repo/"external").resolve()))
    import external_diecasting as lib
    from followon_diecasting import full_source
    with threadpool_limits(limits=1):
        if args.stage in ("validate","both"):
            validate(args,spec,lib)
        if args.stage in ("evaluate","both"):
            evaluate(args,spec,lib,full_source)
