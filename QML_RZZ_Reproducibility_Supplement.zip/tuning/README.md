# Temporal selection of die-casting inspection kernels

This post hoc analysis uses only the first 46 eligible production dates to fit and select model settings. The test outcomes of both subsequent windows were known from earlier research. The validation grid was frozen for this calculation in `tuning_protocol.json`. The SHA-256 digest of that file is recorded alongside the choices before the retrospective test evaluation.

Use Python 3.14 with the pinned dependencies from [the benchmark repository](https://github.com/qkdlsem-maker/qml-inspection-benchmarks/tree/e7068d1ca1d6). Obtain the original two casting CSVs through the source records described in that repository and save them as `data/diecasting_train.csv` and `data/competition_full.csv`. Both files are verified against the original pinned identities at runtime. The commands below assume the benchmark checkout is in `qml-inspection-benchmarks` and the working directory contains this analysis script and protocol.

```sh
python casting_temporal_tuning.py validate --repo qml-inspection-benchmarks --short data/diecasting_train.csv --long data/competition_full.csv --out results
python casting_temporal_tuning.py evaluate --repo qml-inspection-benchmarks --short data/diecasting_train.csv --long data/competition_full.csv --out results
```

The validation stage writes per-date results for all 36 model and parameter combinations, pooled validation counts, training-fold metadata, the selected configurations and a manifest of their digests. The evaluation stage verifies the protocol and choice digests before applying the frozen choices. Running either stage with reversed or incompatible source files raises an error.

`tuning_test_summary.csv` and `tuning_test_by_date.csv` report observed counts for the two original windows. The `shared_q_setting` rows hold the training-selected quantum phase scale and SVM C constant across both variants to estimate the effect of adding the gates. The `individually_tuned` rows use the winning configuration within each family. The `original_setting` rows check the 12 published counts across three kernels, two windows and two eligibility rules. In this finite grid all three independent selectors and the shared selector chose the lowest scale multiplier. An optimal value beyond the grid cannot be inferred.
