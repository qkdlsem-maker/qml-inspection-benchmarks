"""Reproduce the one-time exploratory expansion of the casting validation grid."""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd
from threadpoolctl import threadpool_limits

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import casting_temporal_tuning as parent


def expand(args, rule, lib):
    base = json.loads((args.original / "tuning_selection_manifest.json").read_text(encoding="utf-8"))
    assert base["protocol_sha256"] == rule["parent_protocol_sha256"]
    assert parent.sha(args.short.read_bytes()) == base["input_sha256_short"]
    anchor = pd.read_csv(args.original/"tuning_validation_grid.csv")
    original_choices_path = args.original/"tuning_choices.csv"
    assert parent.sha(original_choices_path.read_bytes()) == base["choices_sha256"]
    original_choices = pd.read_csv(original_choices_path)
    assert anchor.groupby("method").size().eq(12).all()
    shots = parent.load(lib.bytes_for_analysis(args.short),lib)
    train = shots.order[shots.day.loc[shots.order] <= pd.Timestamp("2019-02-20")]
    days = shots.day.loc[train].unique()
    assert (len(days),len(train)) == (46,46696)
    daily = []
    for n in rule["fit_training_days"]:
        fit = parent.sample_rows(parent.select_rows(shots, days[:n]))
        val = parent.select_rows(shots, days[n:n+rule["validation_days_per_fold"]])
        tx, vx, y = parent.prepare_features(shots,fit,[(shots,val)])
        for method in rule["methods"]:
            for scale in rule["additional_scales"]:
                predictions = parent.fit_scores(lib,method,scale,rule["C_candidates"],tx,vx,y)
                for c, scores in predictions.items():
                    for row in parent.summarize(lib,shots,val,scores,"all"):
                        daily.append({"fit_dates":n,"method":method,"scale":scale,"C":c,**row})
        print("Finished boundary fold through",days[n+9].date(),flush=True)
    detail=pd.DataFrame(daily)
    detail.to_csv(args.out/"additional_validation_by_date.csv",index=False)
    grid=pd.concat([anchor,detail.groupby(["method","scale","C"],as_index=False)[["units","slots","defects","hits"]].sum()],ignore_index=True)
    assert grid.groupby("method").size().eq(18).all() and grid[["units","slots","defects"]].nunique().eq(1).all()
    grid.to_csv(args.out/"expanded_validation_grid.csv",index=False)
    chosen = []
    for method in rule["methods"]:
        best = parent.choose(grid[grid.method.eq(method)])
        earlier = original_choices[original_choices.method.eq(method) & original_choices.selection.eq("individually_tuned")].iloc[0]
        assert earlier.validation_hits == anchor[anchor.method.eq(method)].hits.max()
        chosen.append({"selection":"individually_tuned","method":method,"scale":float(best.scale),"C":float(best.C),
                       "validation_hits":int(best.hits),"parent_validation_hits":int(earlier.validation_hits)})
    matched = parent.choose(grid[grid.method.str.startswith("Q4")].groupby(["scale","C"],as_index=False).hits.sum())
    for method in rule["methods"][:2]:
        best = grid[grid.method.eq(method) & grid.scale.eq(matched.scale) & grid.C.eq(matched.C)].iloc[0]
        earlier = original_choices[original_choices.method.eq(method) & original_choices.selection.eq("shared_q_setting")].iloc[0]
        chosen.append({"selection":"shared_q_setting","method":method,"scale":float(best.scale),"C":float(best.C),
                       "validation_hits":int(best.hits),"parent_validation_hits":int(earlier.validation_hits)})
    for row in original_choices[original_choices.selection.eq("original_setting")].to_dict("records"):
        chosen.append({**row,"parent_validation_hits":int(row["validation_hits"])})
    output = pd.DataFrame(chosen)
    output.to_csv(args.out/"tuning_choices.csv",index=False)
    parent.write_json(args.out/"tuning_selection_manifest.json",{
        "protocol_sha256":parent.sha(args.protocol.read_bytes()),"choices_sha256":parent.sha((args.out/"tuning_choices.csv").read_bytes()),
        "parent_choices_sha256":base["choices_sha256"],"original_grid_sha256":parent.sha((args.original/"tuning_validation_grid.csv").read_bytes())
    })
    print(output.to_string(index=False),flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage",choices=["validate","evaluate","both"])
    for flag in ("repo","short","long","original","out"):
        parser.add_argument("--"+flag,type=Path,required=True)
    parser.add_argument("--protocol",type=Path,default=Path(__file__).with_name("boundary_protocol.json"))
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    rule=json.loads(args.protocol.read_text(encoding="utf-8"))
    sys.path.insert(0,str((args.repo/"external").resolve()))
    import external_diecasting as lib
    from followon_diecasting import full_source
    with threadpool_limits(limits=1):
        if args.stage in ("validate","both"):
            expand(args,rule,lib)
        if args.stage in ("evaluate","both"):
            parent.evaluate(args,rule,lib,full_source)
