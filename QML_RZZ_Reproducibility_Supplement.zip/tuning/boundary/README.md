# Lower-bound diagnostic

All original validation winners used the smallest multiplier in the initial 12-candidate grid. The separate protocol in this folder specifies a single retrospective extension, giving each model the same added multipliers and SVM C candidates. The original results are retained for comparison.

After reproducing the parent analysis, execute these commands from its directory using the same local source files and benchmark checkout.

```sh
python boundary/expand_lower_scales.py validate --repo qml-inspection-benchmarks --short data/diecasting_train.csv --long data/competition_full.csv --original results --out boundary/results
python boundary/expand_lower_scales.py evaluate --repo qml-inspection-benchmarks --short data/diecasting_train.csv --long data/competition_full.csv --original results --out boundary/results
```

The script reuses the original validation grid, verifies its winning counts, computes the six new candidates per method and writes each of the expanded choices before evaluating the two previously studied test windows. Its test-result filenames have the same structure as those of the parent analysis. All diagnostic files reside in this separate folder.
